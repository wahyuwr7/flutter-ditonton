import 'package:dartz/dartz.dart';
import 'package:ditonton/domain/repositories/tv_repository.dart';

import '../../common/failure.dart';
import '../entities/tv.dart';

class GetTvOnAir {
  final TvRepository repository;

  GetTvOnAir(this.repository);

  Future<Either<Failure, List<Tv>>> execute() {
    return repository.getTvOnAir();
  }
}
