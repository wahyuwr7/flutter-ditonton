package com.dicoding.ditonton

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
